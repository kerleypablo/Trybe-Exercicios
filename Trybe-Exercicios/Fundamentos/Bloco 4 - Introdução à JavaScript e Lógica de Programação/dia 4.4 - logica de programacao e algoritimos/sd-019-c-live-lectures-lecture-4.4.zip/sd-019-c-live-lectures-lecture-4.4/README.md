# Repositório de Aulas ao Vivo Da Turma 19 - Tribo C -> 💻 🎥

Este repositório armazena os códigos e scripts fornecidos durante as aulas ao vivo pelas pessoas especialistas da Trybe.

## Começando

Basta clonar o repositório:

```
git clone git@github.com:tryber/sd-019-c-live-lectures.git
```

Em seguida acesse a branch do Pull Request da aula seguindo o padrão de nomenclatura das branchs (lecture/nome-da-aula).

Exemplo:

```
git checkout lecture/3.1
```

### Estrutura

Todos os conteúdos dados em aulas estarão no seu respectivo Pull Request! 😉🚀